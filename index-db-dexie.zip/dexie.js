var db = new Dexie("MyBikeIndexDB");
//+++++++++++++++++++++++++++++++++++++++++++++++++
// DB with single table "bikes" with primary key "id" and
// indexes on properties "name" and "model"
//+++++++++++++++++++++++++++++++++++++++++++++++++
db.version(1).stores({
    bikes: "id,name,model,year",
});
//+++++++++++++++++++++++++++++++++++++++++++++++++
// Now add some values.
//+++++++++++++++++++++++++++++++++++++++++++++++++
db.bikes.bulkPut([
    {id: 1,  name: "Yamaha", model: "YZF R1M.", year: 2017 },
    {id: 2,  name: "CBR ", model: "1000RR", year: 2018 },
    {id: 3,  name: "Ducati", model: "Panigale V4", year: 2022 },
    {id: 4,  name: "BMW", model: "S 1000 RR", year: 2015 },
    {id: 5,  name: "Kawasaki", model: "Ninja ZX-10R" },
    {id: 6,  name: "Kawasaki", model: "Ninja ZX-15R" },
]).then(() => {
    db.bikes.put({id: 7, name: "Yamaha-Single", model: "YZF.", year: 2019 });
}).then(() => {
    db.bikes.update(7, { name: "Yamaha-Single", model: "YZF.", year: 2023 });
}).then(() => {
    return db.bikes.where("year").between(2015, 2019).toArray();
}).then(bikes => {
    console.log("Found Bikes: " + bikes.map(bike => `${bike.name} ${bike.model}`));
    return db.bikes.orderBy("name").reverse().toArray();
}).then(bikes => {
    console.log("Bikes in Reverse Order: " + bikes.map(bike => `${bike.name} ${bike.model}`));
    return db.bikes.where('name').startsWith("K").toArray();
}).then(bikes => {
    console.log("Bikes With K-: " + bikes.map(bike => `${bike.name} ${bike.model}`));
    return db.bikes.where('name').startsWith("K").keys();
}).then(bikes => {
    console.log("Bikes With 'K-single': " + bikes);
    return db.bikes.get({name: "Yamaha"});
}).then(bikes => {
    console.log("Bikes With 'Bike-Data-1': "  + bikes.name + '__' + bikes.model);
    return db.bikes.where({name: "Kawasaki"}).toArray();
}).then(bikes => {
    console.log("Bikes With 'Bike-Data-2': " + bikes.map(bike => `${bike.name} ${bike.model}`));
    return db.bikes.where({name: "BMW"}).first();
}).then(bikes => {
    console.log("Bikes With 'Bike-Data-3': " + bikes.name + '__' + bikes.model);
    return db.bikes.where("year").above(2018).toArray();
}).then(bikes => {
    console.log("Bikes With 'Bike-Data-4': " + bikes.map(bike => `${bike.name} ${bike.model}`));
    return db.bikes.where("year").above(2018).or('year').below(2019).toArray();
}).then(bikes => {
    console.log("Bikes With 'Bike-Data-5': " + bikes.map(bike => `${bike.name} ${bike.model}`));
}).catch(err => {
    console.log("Ouch... " + err);
});